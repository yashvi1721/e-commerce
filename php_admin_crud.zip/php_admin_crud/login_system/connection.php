<?php 
$con = mysqli_connect('localhost', 'root', '', 'cart_db');
?>