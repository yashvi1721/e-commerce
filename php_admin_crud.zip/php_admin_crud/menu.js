
$(document).ready(function(){
  $('#icon1').click(function(){
    $('ul').toggleClass('show')
  });
});
